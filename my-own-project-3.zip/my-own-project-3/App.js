import * as React from 'react';

import {createSwitchNavigator, createAppContainer} from "react-navigation";

//importing the screens
//import Calculate from "./screens/Calculate";
//import Dashboard from "./screens/Dashboard";
import Login from "./screens/Login";
//import Logout from "./screens/Logout";
//import Profile from "./screens/Profile";
//import SavedCalculations from "./screens/SavedCalculations";








const AppSwitchNavigator = createSwitchNavigator({
    
    Login: Login,
    //Dashboard: Dashboard,
    //Logout: Logout,
    //Profile: Profile,
    //Calculate: Calculate,
    //SavedCalculations: SavedCalculations
})

const AppNavigator = createAppContainer(AppSwitchNavigator);

export default function App() {
    return <AppNavigator />
    
}



